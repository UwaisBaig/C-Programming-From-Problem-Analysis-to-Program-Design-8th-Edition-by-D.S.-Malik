#include <iostream>

using namespace std;

int main()
{
    int i;

    for (i = 1; i <= 20; i = i + 2)
        cout << " " << i;

    cout << endl;

    return 0;
}
