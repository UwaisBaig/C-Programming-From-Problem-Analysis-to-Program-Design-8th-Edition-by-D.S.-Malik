#include <iostream>

using namespace std;

int main()
{
    int i = 20;

    while (i < 20){
    cout << i << " ";
    i = i + 5;
    }
    cout << endl;
    return 0;
}
