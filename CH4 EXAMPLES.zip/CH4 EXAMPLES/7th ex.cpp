#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main() {
    ifstream inFile;
    ofstream outFile;
    double test1, test2, test3, test4, test5, average;
    string firstName, lastName;

    inFile.open("test.txt");
    if (!inFile) {
        cout << "Cannot open the input file. The program terminates." << endl;
        return 1;
    }

    outFile.open("testavg.out");

    cout << "Processing data..." << endl;

    inFile >> firstName >> lastName;
    outFile << "Student name: " << firstName << " " << lastName << endl;

    inFile >> test1 >> test2 >> test3 >> test4 >> test5;

    outFile << "Test scores: " 
            << test1 << " " << test2 << " " << test3 << " " << test4 << " " << test5 << endl;

    average = (test1 + test2 + test3 + test4 + test5) / 5.0;
    outFile << "Average test score: " << average << endl;

    inFile.close();
    outFile.close();

    cout << "Results saved in testavg.out file." << endl;

    return 0;
}
